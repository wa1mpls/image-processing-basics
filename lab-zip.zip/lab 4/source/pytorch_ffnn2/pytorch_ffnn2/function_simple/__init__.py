from function_simple.activation import Activation
from function_simple.activation_prime import ActivationPrime

from function_simple.loss import Loss
from function_simple.loss_prime import LossPrime
