from layer_simple.fc_layer import FCLayer
from layer_simple.act_layer import ActivationLayer
