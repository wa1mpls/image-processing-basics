from network_simple.network import Network
